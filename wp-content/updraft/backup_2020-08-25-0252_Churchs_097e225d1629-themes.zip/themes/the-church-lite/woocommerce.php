<?php get_header(); ?>
<div class="container">
    	<div id="site-pagelayout">
			<?php woocommerce_content(); ?>
		</div><!-- site-pagelayout -->
</div><!-- container -->     
<?php get_footer(); ?>